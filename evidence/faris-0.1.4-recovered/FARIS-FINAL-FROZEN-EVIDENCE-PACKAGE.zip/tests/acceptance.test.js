'use strict';
const assert = require('node:assert');
const { FarisOrchestrator } = require('../src/orchestrator');

let pass = 0;
let fail = 0;
function t(label, cond) {
  if (cond) { pass++; console.log(`PASS ${label}`); }
  else { fail++; console.log(`FAIL ${label}`); }
}

(async () => {
  try {
    const orch = new FarisOrchestrator();
    orch.registerSkill('create', { async execute() { return { status: 'SUCCESS', data: 'ok' }; } });

    // T01 blocked action
    const rBlocked = await orch.execute({ task_id: 't01', action: 'drop_users', target: 'x', version: 'v1' });
    t('riskgate-blocked', rBlocked.status === 'COMPLETED' && rBlocked.final_decision === 'STOP');

    // T02 write -> waiting for approval
    const rWrite = await orch.execute({ task_id: 't02', action: 'create', target: 'users', version: 'v1' });
    t('t02-waiting-for-approval', rWrite.status === 'WAITING_FOR_APPROVAL' && !!rWrite.interrupt_payload);

    // T03 binding present
    t('t03-binding-present', !!rWrite.interrupt_payload && !!rWrite.interrupt_payload.binding && rWrite.interrupt_payload.binding.task_id === 't02');

    // T04 snapshot includes human_approval
    const snapshot = await orch.graph.getState({ configurable: { thread_id: rWrite.thread_id } });
    t('t04-snapshot-next-human_approval', Array.isArray(snapshot.next) && snapshot.next.includes('human_approval'));

    // T05 resume approved
    const resumed = await orch.resume({ thread_id: rWrite.thread_id, approved: true, binding: rWrite.interrupt_payload.binding });
    t('t05-resume-completed', resumed.status === 'COMPLETED');

    // T06 resume rejected -> STOP
    const rWrite2 = await orch.execute({ task_id: 't06', action: 'create', target: 'users', version: 'v2' });
    const rejected = await orch.resume({ thread_id: rWrite2.thread_id, approved: false, binding: rWrite2.interrupt_payload.binding });
    t('t06-rejected-stop', rejected.status === 'COMPLETED' && rejected.final_decision === 'STOP');

    // T07 binding mismatch while paused -> error
    const rWrite3 = await orch.execute({ task_id: 't07', action: 'create', target: 'users', version: 'v3' });
    let mismatch = false;
    try {
      await orch.resume({ thread_id: rWrite3.thread_id, approved: true, binding: { task_id: 'WRONG', action: 'create', target: 'users', version: 'v3' } });
    } catch (e) { mismatch = e.message === 'BINDING_MISMATCH'; }
    t('t07-binding-mismatch-paused', mismatch);

    // T08 resume after completion -> INVALID_RESUME_STATE
    // First complete the pending approval
    await orch.resume({ thread_id: rWrite3.thread_id, approved: true, binding: rWrite3.interrupt_payload.binding });
    let invalidAfterComplete = false;
    try {
      await orch.resume({ thread_id: rWrite3.thread_id, approved: true, binding: rWrite3.interrupt_payload.binding });
    } catch (e) { invalidAfterComplete = e.message === 'INVALID_RESUME_STATE'; }
    t('t08-invalid-resume-after-complete', invalidAfterComplete);

    // T09 null action blocked
    const rNull = await orch.execute({ task_id: 't09', action: null, target: 'x', version: 'v1' });
    t('t09-null-action-blocked', rNull.status === 'COMPLETED' && rNull.final_decision === 'STOP');

    // T10 read-only auto-approved
    orch.registerSkill('read', { async execute() { return { status: 'SUCCESS', data: 'list' }; } });
    const rRead = await orch.execute({ task_id: 't10', action: 'read', target: 'x', version: 'v1' });
    t('t10-read-only-completed', rRead.status === 'COMPLETED' && rRead.human_decision === 'APPROVED');

    // T11 idempotency same key
    const rIdem1 = await orch.execute({ task_id: 't11', action: 'create', target: 'users', version: 'v1' });
    const rIdem2 = await orch.execute({ task_id: 't11', action: 'create', target: 'users', version: 'v1' });
    t('t11-idempotency-same-key', rIdem1.status === 'WAITING_FOR_APPROVAL' && rIdem2.status === 'WAITING_FOR_APPROVAL');

    // T12 verifier fail on error status -> resume ends at STOP
    orch.registerSkill('failskill', { async execute() { return { status: 'ERROR' }; } });
    const rFail = await orch.execute({ task_id: 't12', action: 'failskill', target: 'x', version: 'v1' });
    let resumedFail = null;
    if (rFail.status === 'WAITING_FOR_APPROVAL') {
      resumedFail = await orch.resume({ thread_id: rFail.thread_id, approved: true, binding: rFail.interrupt_payload.binding });
    } else {
      resumedFail = rFail;
    }
    t('t12-verifier-fail-closed', resumedFail.status === 'COMPLETED' && resumedFail.final_decision === 'STOP');

    // T13 wrong-thread resume -> error
    let wrongThread = false;
    try {
      await orch.resume({ thread_id: 'thread-NONEXISTENT', approved: true, binding: {} });
    } catch (e) { wrongThread = e.message === 'INVALID_RESUME_STATE' || e.message.includes('thread'); }
    t('t13-wrong-thread-resume', wrongThread);

    // T14 pending interrupt cannot be marked COMPLETED without approval
    const rWrite4 = await orch.execute({ task_id: 't14', action: 'create', target: 'users', version: 'v4' });
    t('t14-pending-interrupt-not-completed', rWrite4.status === 'WAITING_FOR_APPROVAL');

    console.log(`\nACCEPTANCE SUMMARY: PASS=${pass} FAIL=${fail}\n`);
    process.exit(fail === 0 ? 0 : 1);
  } catch (e) {
    console.error('FATAL', e.message);
    process.exit(2);
  }
})();
