'use strict';
const { FarisOrchestrator } = require('../src/orchestrator');

let pass = 0;
let fail = 0;
function t(label, ok) {
  if (ok) { pass++; console.log(`PASS ${label}`); }
  else { fail++; console.log(`FAIL ${label}`); }
}

(async () => {
  try {
    const orch = new FarisOrchestrator();
    orch.registerSkill('create', { async execute() { return { status: 'SUCCESS', data: 'ok' }; } });

    // DUR-01 resume idempotent within same process
    const r1 = await orch.execute({ task_id: 'dur01', action: 'create', target: 'users', version: 'v1' });
    const resumed = await orch.resume({ thread_id: r1.thread_id, approved: true, binding: r1.interrupt_payload.binding });
    t('dur01-resume-idempotent', resumed.status === 'COMPLETED' && resumed.skill_result?.status === 'SUCCESS');

    // DUR-02 concurrency: real concurrent resume not possible in single process without external harness.
    // Mark as NOT VERIFIED because we cannot simulate true concurrency safely here.
    console.log('NOT VERIFIED dur02-concurrent-resume (no concurrent harness available)');

    // DUR-03 same key different thread within process
    const r2 = await orch.execute({ task_id: 'dur01', action: 'create', target: 'users', version: 'v1' });
    t('dur03-same-key-different-thread', r2.status === 'WAITING_FOR_APPROVAL');

    console.log(`\nDURABILITY SUMMARY: PASS=${pass} FAIL=${fail}\n`);
    process.exit(0);
  } catch (e) {
    console.error('FATAL', e.message);
    process.exit(2);
  }
})();
