'use strict';
module.exports = {
  max_replan_attempts: 2,
  blocked_actions: ['drop_users', 'disable_rls', 'expose_secrets'],
  write_actions: ['create', 'update', 'delete', 'deploy', 'merge', 'publish']
};
