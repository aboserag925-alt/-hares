'use strict';
class IdempotencyStore {
  constructor() {
    this.store = new Map();
    this._type = 'in-memory-prototype';
  }
  async get(key) { return this.store.get(key) || null; }
  async set(key, value) { this.store.set(key, value); }
  async has(key) { return this.store.has(key); }
  async delete(key) { this.store.delete(key); }
  async clear() { this.store.clear(); }
  getType() { return this._type; }
}
module.exports = { IdempotencyStore };
