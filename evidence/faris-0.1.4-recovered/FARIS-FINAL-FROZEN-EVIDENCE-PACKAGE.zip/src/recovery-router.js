'use strict';
const policies = require('./policies');

class RecoveryRouter {
  constructor({ replanStrategy = 'stop' } = {}) {
    this.replanStrategy = replanStrategy;
  }

  route(state) {
    const rc = state.replan_count;

    if (state.risk_decision === 'BLOCKED') {
      return {
        final_decision: 'STOP',
        execution_log: [{ step: 'router', decision: 'STOP', reason: 'blocked' }]
      };
    }

    if (state.human_decision === 'REJECTED') {
      return {
        final_decision: 'STOP',
        execution_log: [{ step: 'router', decision: 'STOP', reason: 'rejected' }]
      };
    }

    if (state.verifier_result && state.verifier_result.status === 'FAIL') {
      if (this.replanStrategy === 'modify' && rc < policies.max_replan_attempts) {
        return {
          replan_count: rc + 1,
          final_decision: 'REPLAN',
          replan_modification: {
            target: `${state.target}-retry-${rc + 1}`,
            strategy: 'modified_target'
          },
          execution_log: [{ step: 'router', decision: 'REPLAN', count: rc + 1, modification: 'target' }]
        };
      }

      if (this.replanStrategy === 'needs_review') {
        return {
          final_decision: 'NEEDS_REVIEW',
          execution_log: [{ step: 'router', decision: 'NEEDS_REVIEW', reason: 'verifier_failed' }]
        };
      }

      return {
        final_decision: 'STOP',
        execution_log: [{ step: 'router', decision: 'STOP', reason: 'verifier_failed' }]
      };
    }

    if (state.post_deploy_verify && state.post_deploy_verify.status === 'FAIL') {
      return {
        final_decision: 'DEBUG',
        execution_log: [{ step: 'router', decision: 'DEBUG' }]
      };
    }

    if (state.verifier_result?.status === 'PASS' && state.post_deploy_verify?.status === 'PASS') {
      return {
        final_decision: 'ENOUGH',
        execution_log: [{ step: 'router', decision: 'ENOUGH' }]
      };
    }

    return {
      final_decision: 'STOP',
      execution_log: [{ step: 'router', decision: 'STOP', reason: 'default' }]
    };
  }
}

module.exports = { RecoveryRouter };
