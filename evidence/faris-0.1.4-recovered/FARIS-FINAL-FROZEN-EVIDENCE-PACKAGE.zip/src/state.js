'use strict';
module.exports = {
  thread_id: null,
  task_id: null,
  action: null,
  target: null,
  version: null,
  is_write_operation: null,

  risk_decision: null,
  risk_reason: null,

  idempotency_key: null,

  skill_result: null,
  verifier_result: null,

  human_decision: null,
  approval_binding: null,

  post_deploy_verify: null,
  final_decision: null,
  replan_count: 0,
  replan_modification: null,
  execution_log: []
};
