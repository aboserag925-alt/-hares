'use strict';
const policies = require('./policies');

class RiskGate {
  evaluate({ action }) {
    try {
      if (!action || typeof action !== 'string') {
        return { decision: 'BLOCKED', reason: 'action missing or invalid' };
      }
      if (policies.blocked_actions.includes(action)) {
        return { decision: 'BLOCKED', reason: `action ${action} is in blocked_actions` };
      }
      if (policies.write_actions.includes(action)) {
        return { decision: 'NEEDS_REVIEW', reason: 'write operation requires human approval' };
      }
      return { decision: 'ALLOWED', reason: 'read-only operation' };
    } catch (err) {
      return { decision: 'BLOCKED', reason: `risk_gate_exception: ${err.message}` };
    }
  }
}
module.exports = { RiskGate };
