'use strict';
const { StateGraph, START, END, interrupt, Command } = require('@langchain/langgraph');
const { RiskGate } = require('./risk-gate');
const { RecoveryRouter } = require('./recovery-router');
const policies = require('./policies');

function buildGraph() {
  const graph = new StateGraph({
    channels: {
      thread_id: { value: (_c, u) => u, default: () => null },
      task_id: { value: (_c, u) => u, default: () => null },
      action: { value: (_c, u) => u, default: () => null },
      target: { value: (_c, u) => u, default: () => null },
      version: { value: (_c, u) => u, default: () => null },
      is_write_operation: { value: (_c, u) => u, default: () => null },
      risk_decision: { value: (_c, u) => u, default: () => null },
      risk_reason: { value: (_c, u) => u, default: () => null },
      idempotency_key: { value: (_c, u) => u, default: () => null },
      skill_result: { value: (_c, u) => u, default: () => null },
      verifier_result: { value: (_c, u) => u, default: () => null },
      human_decision: { value: (_c, u) => u, default: () => null },
      approval_binding: { value: (_c, u) => u, default: () => null },
      post_deploy_verify: { value: (_c, u) => u, default: () => null },
      final_decision: { value: (_c, u) => u, default: () => null },
      replan_count: { value: (_c, u) => u, default: () => 0 },
      replan_modification: { value: (_c, u) => u, default: () => null },
      execution_log: { value: (a, b) => [...a, ...b], default: () => [] }
    }
  });

  graph.addNode('risk_gate', async (state, config) => {
    const rg = new RiskGate();
    const result = rg.evaluate({ action: state.action });
    return {
      risk_decision: result.decision,
      risk_reason: result.reason,
      execution_log: [{ step: 'risk_gate', decision: result.decision }]
    };
  });

  graph.addNode('adapter', async (state) => {
    let target = state.target;
    let version = state.version;

    if (state.replan_modification) {
      if (state.replan_modification.target) {
        target = state.replan_modification.target;
      }
      if (state.replan_modification.version) {
        version = state.replan_modification.version;
      }
    }

    const key = `${state.task_id}:${state.action}:${target}:${version}`;
    const isWrite = policies.write_actions.includes(state.action);

    return {
      target,
      version,
      idempotency_key: key,
      is_write_operation: isWrite,
      execution_log: [{ step: 'adapter', idempotency_key: key, is_write: isWrite, replanned: !!state.replan_modification }]
    };
  });

  graph.addNode('human_approval', async (state, config) => {
    if (!state.is_write_operation) {
      return {
        human_decision: 'APPROVED',
        approval_binding: {
          task_id: state.task_id,
          action: state.action,
          target: state.target,
          version: state.version
        },
        execution_log: [{ step: 'human_approval', auto: true }]
      };
    }

    const resumeValue = interrupt({
      type: 'HUMAN_APPROVAL_REQUEST',
      binding: {
        task_id: state.task_id,
        action: state.action,
        target: state.target,
        version: state.version
      }
    });

    if (!resumeValue || typeof resumeValue !== 'object') {
      throw new Error('HUMAN_APPROVAL_INVALID_PAYLOAD');
    }

    const expected = {
      task_id: state.task_id,
      action: state.action,
      target: state.target,
      version: state.version
    };
    const actual = resumeValue.binding || {};
    const bindingMatch =
      actual.task_id === expected.task_id &&
      actual.action === expected.action &&
      actual.target === expected.target &&
      actual.version === expected.version;

    if (!bindingMatch) {
      throw new Error('BINDING_MISMATCH');
    }

    const decision = resumeValue.approved === true ? 'APPROVED' : 'REJECTED';
    return {
      human_decision: decision,
      approval_binding: expected,
      execution_log: [{ step: 'human_approval', decision, binding_verified: true }]
    };
  });

  graph.addNode('execute', async (state, config) => {
    const registry = config.configurable.registry;
    const idempotency = config.configurable.idempotency;
    const skill = registry.get(state.action);

    if (!skill) {
      return {
        skill_result: { status: 'ERROR', reused: false, data: null },
        execution_log: [{ step: 'execute', error: 'skill_not_found' }]
      };
    }

    const existing = await idempotency.get(state.idempotency_key);
    if (existing) {
      return {
        skill_result: { ...existing, reused: true },
        execution_log: [{ step: 'execute', reused: true }]
      };
    }

    try {
      const result = await skill.execute({
        task_id: state.task_id,
        target: state.target,
        version: state.version
      });
      await idempotency.set(state.idempotency_key, result);
      return {
        skill_result: { ...result, reused: false },
        execution_log: [{ step: 'execute', reused: false }]
      };
    } catch (err) {
      return {
        skill_result: { status: 'ERROR', reused: false, data: null, error: err.message },
        execution_log: [{ step: 'execute', error: err.message }]
      };
    }
  });

  graph.addNode('verifier', async (state) => {
    const r = state.skill_result;
    if (!r) return { verifier_result: { status: 'FAIL', reason: 'no_skill_result' },
      execution_log: [{ step: 'verifier', status: 'FAIL', reason: 'no_skill_result' }] };
    if (r.status === 'UNKNOWN') return { verifier_result: { status: 'FAIL', reason: 'unknown_status' },
      execution_log: [{ step: 'verifier', status: 'FAIL', reason: 'unknown_status' }] };
    if (r.status === 'ERROR') return { verifier_result: { status: 'FAIL', reason: 'error_status' },
      execution_log: [{ step: 'verifier', status: 'FAIL', reason: 'error_status' }] };
    if (r.status !== 'SUCCESS') return { verifier_result: { status: 'FAIL', reason: 'invalid_status' },
      execution_log: [{ step: 'verifier', status: 'FAIL', reason: 'invalid_status' }] };
    return { verifier_result: { status: 'PASS', reason: 'verified' },
      execution_log: [{ step: 'verifier', status: 'PASS' }] };
  });

  // PATCHED: Node name changed from 'post_deploy_verify' to 'post_deploy_verify_node'
  graph.addNode('post_deploy_verify_node', async (state, config) => {
    const checker = config.configurable.postDeployChecker;
    if (!checker) {
      return { post_deploy_verify: { status: 'FAIL' },
        execution_log: [{ step: 'post_deploy_verify', status: 'FAIL', reason: 'no_checker' }] };
    }
    try {
      const ok = await checker(state);
      return { post_deploy_verify: { status: ok ? 'PASS' : 'FAIL' },
        execution_log: [{ step: 'post_deploy_verify', status: ok ? 'PASS' : 'FAIL' }] };
    } catch {
      return { post_deploy_verify: { status: 'FAIL' },
        execution_log: [{ step: 'post_deploy_verify', status: 'FAIL', reason: 'exception' }] };
    }
  });

  graph.addNode('router', async (state, config) => {
    const replanStrategy = config.configurable.replanStrategy || 'stop';
    const router = new RecoveryRouter({ replanStrategy });
    return router.route(state);
  });

  graph.addEdge(START, 'risk_gate');

  graph.addConditionalEdges('risk_gate', (s) => s.risk_decision, {
    BLOCKED: 'router',
    ALLOWED: 'adapter',
    NEEDS_REVIEW: 'adapter'
  });

  graph.addEdge('adapter', 'human_approval');

  graph.addConditionalEdges('human_approval', (s) => s.human_decision, {
    APPROVED: 'execute',
    REJECTED: 'router',
    null: END
  });

  graph.addEdge('execute', 'verifier');

  // PATCHED: Edge target changed from 'post_deploy_verify' to 'post_deploy_verify_node'
  graph.addConditionalEdges('verifier', (s) => s.verifier_result?.status, {
    PASS: 'post_deploy_verify_node',
    FAIL: 'router'
  });

  // PATCHED: Edge source changed from 'post_deploy_verify' to 'post_deploy_verify_node'
  graph.addEdge('post_deploy_verify_node', 'router');

  graph.addConditionalEdges('router', (s) => s.final_decision, {
    ENOUGH: END,
    STOP: END,
    DEBUG: END,
    NEEDS_REVIEW: 'human_approval',
    REPLAN: 'adapter'
  });

  return graph;
}

module.exports = { buildGraph };
