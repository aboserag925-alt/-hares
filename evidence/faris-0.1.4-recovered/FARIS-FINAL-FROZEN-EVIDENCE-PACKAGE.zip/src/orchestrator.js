'use strict';
const { MemorySaver, Command } = require('@langchain/langgraph');
const { buildGraph } = require('./graph');
const { SkillRegistry } = require('./skill-registry');
const { IdempotencyStore } = require('./idempotency-store');

class FarisOrchestrator {
  constructor({ postDeployChecker, replanStrategy } = {}) {
    this.registry = new SkillRegistry();
    this.idempotency = new IdempotencyStore();
    this.graph = buildGraph().compile({
      checkpointer: new MemorySaver()
    });
    this.postDeployChecker = postDeployChecker || null;
    this.replanStrategy = replanStrategy || 'stop';
  }

  registerSkill(action, skill) {
    this.registry.register(action, skill);
  }

  _config(thread_id) {
    return {
      configurable: {
        thread_id,
        registry: this.registry,
        idempotency: this.idempotency,
        postDeployChecker: this.postDeployChecker,
        replanStrategy: this.replanStrategy
      }
    };
  }

  async _wrap(thread_id, result) {
    const config = this._config(thread_id);
    const state = await this.graph.getState(config);
    const isPaused = state.next && state.next.includes('human_approval');

    if (isPaused) {
      const interrupts = state.tasks?.flatMap(t => t.interrupts || []) || [];
      const payload = interrupts.length > 0 ? interrupts[0].value : null;
      return {
        status: 'WAITING_FOR_APPROVAL',
        thread_id,
        interrupt_payload: payload
      };
    }
    return { status: 'COMPLETED', thread_id, ...state.values };
  }

  async execute({ task_id, action, target, version }) {
    const thread_id = `thread-${task_id}`;
    const input = {
      thread_id, task_id, action, target, version,
      is_write_operation: null,
      risk_decision: null, risk_reason: null,
      idempotency_key: null,
      skill_result: null, verifier_result: null,
      human_decision: null, approval_binding: null,
      post_deploy_verify: null, final_decision: null,
      replan_count: 0, replan_modification: null, execution_log: []
    };
    const result = await this.graph.invoke(input, this._config(thread_id));
    return this._wrap(thread_id, result);
  }

  async resume({ thread_id, approved, binding }) {
    const config = this._config(thread_id);
    const current = await this.graph.getState(config);
    const isPaused = current.next && current.next.includes('human_approval');
    if (!isPaused) {
      throw new Error('INVALID_RESUME_STATE');
    }
    const result = await this.graph.invoke(
      new Command({ resume: { approved, binding } }),
      config
    );
    return this._wrap(thread_id, result);
  }
}

module.exports = { FarisOrchestrator };
