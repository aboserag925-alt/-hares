'use strict';
class SkillRegistry {
  constructor() { this.skills = new Map(); }
  register(id, skill) { this.skills.set(id, skill); }
  get(id) { return this.skills.get(id); }
  has(id) { return this.skills.has(id); }
}
module.exports = { SkillRegistry };
