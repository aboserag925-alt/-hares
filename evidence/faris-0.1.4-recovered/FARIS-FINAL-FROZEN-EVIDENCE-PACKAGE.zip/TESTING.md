# FARIS V2 Testing Specification

See tests/acceptance.test.js and tests/durability.test.js
