'use strict';
require('./tests/acceptance.test.js');
require('./tests/durability.test.js');
require('./tests/contract-v3.test.js');
