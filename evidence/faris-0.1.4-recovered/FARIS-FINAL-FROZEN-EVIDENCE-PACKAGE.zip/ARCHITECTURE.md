# FARIS V2 Architecture

See main design documentation.
