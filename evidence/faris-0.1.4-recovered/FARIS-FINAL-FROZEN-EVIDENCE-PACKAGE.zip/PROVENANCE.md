# FARIS V2 Candidate 0.1.4 Provenance (P0 Complete)

VERSION: 0.1.4
PARENT VERSION: 0.1.3
PARENT CANDIDATE SHA256: f2e15ad51df65932da8d4ce6212f2807686acda484bf5c2d868586374c383717  (faris-0.1.3-FROZEN-EVIDENCE-PACKAGE.zip)
PARENT EVIDENCE ZIP SHA256: f2e15ad51df65932da8d4ce6212f2807686acda484bf5c2d868586374c383717

PATCH DIFF:
  - src/orchestrator.js – added fail-closed guard in resume(): reject any resume when graph is not paused at human_approval (throws INVALID_RESUME_STATE).
  - tests/acceptance.test.js – replaced stub with 14 real IN-MEMORY acceptance tests.
  - tests/durability.test.js – replaced stub with within-process durability checks; DUR-02 marked NOT VERIFIED.
  - tests/contract-v3.test.js – added full Acceptance Contract v3 coverage (RG, HITL, IDEM, EXEC, VER, REC, REPLAN, ROUTE, STATE, DUR).
  - run_tests.js – custom runner (node --test fails in this Android Harness environment).

PATCH SHA256:
  src/orchestrator.js   22ab6296b306f5567fb090b525eb4e6488bf6ee8b090aeb8e0816229df089226
  tests/acceptance.test.js   23e91b567f5f0f42dfa523ca944b047df863bd075439267a8f956c40cfb0d822
  tests/contract-v3.test.js   5f0dc3a128786fc3df94e8b3a97637f63fd2225569a6ee78f35e85cfe65d22aa

SOURCE SHA256 (before patch – from 0.1.3 baseline):
  src/graph.js               130d6e448f6d2799f1c41faf543c6c5e470954c6147f878b2557bc798bdbf281
  src/orchestrator.js        430d10c54789881d0ee37133b51cf5880bc76c87c2442287cd9c2482bd19f968

SOURCE SHA256 (after patch):
  src/graph.js               166e5c026306399aa680f55ee75fefd984786676b0cde56246ae13bbe9b9559d
  src/idempotency-store.js   8812be65372ee2a2fa2ffffbcd849ae300b01b4effb5ff67478e02fece87585c
  src/index.js               ae36a3c74ce464527a1490439cfe11f569f2d95acb718f820c57951005af9770
  src/orchestrator.js        22ab6296b306f5567fb090b525eb4e6488bf6ee8b090aeb8e0816229df089226
  src/policies.js            b9a85e1a07c6630228f2b06ecd96df2f2eda828ee9631fcde5ac695bc80c1cb5
  src/recovery-router.js     dd1dce923b5234dfd9ad1fca6bcd97d12a22855e9c1816fba59f6b343529c37a
  src/risk-gate.js           8e38aa0408aec7ccb77fdef90f417d4a4372295fe8d1f20512fc9f2f3fe10384
  src/skill-registry.js      4e54ff63bfdbdf55e3157b2026bf1dc76973a4d77b2fecc66511c2f28dc75180
  src/state.js               be7b78ef9269f8714e82ff751a68da6ab3fd934013e2ded929c507a95eb4f8de

PACKAGE-LOCK SHA256: 21e037d06b5c8b2950f83c2ba67501040e41553268bd76d47d7d9f6f402c2f1a

TEST HARNESS SHA256:
  run_tests.js               f203ad3d90f0456134ae6778f6954f6aa9ab50da6d5dac8e33869e40c424d574
  tests/acceptance.test.js   23e91b567f5f0f42dfa523ca944b047df863bd075439267a8f956c40cfb0d822
  tests/contract-v3.test.js   5f0dc3a128786fc3df94e8b3a97637f63fd2225569a6ee78f35e85cfe65d22aa
  tests/durability.test.js   c58cce6bf159de210736da47d0841464ad2e18825a10e82f8c8f981b9bf6c8b7

RAW LOGS:
  raw-tests.log   SHA256: 6a5148258c057a91166914790e28982b584dcdaee16fd1b8de8926fecbfa88fc
    (contains acceptance.log + durability.log + contract-v3.log)

COVERAGE MATRIX (Acceptance Contract v3):
  RG-01        PASS   raw-tests.log (blocked_actions rejected)
  RG-02        PASS   raw-tests.log (read-only auto-approved)
  HITL-01      PASS   raw-tests.log (write pauses at human_approval)
  HITL-02      PASS   raw-tests.log (binding present in interrupt payload)
  HITL-03      PASS   raw-tests.log (snapshot includes human_approval)
  HITL-04      PASS   raw-tests.log (resume approved completes)
  HITL-05      PASS   raw-tests.log (resume rejected -> STOP)
  HITL-06      PASS   raw-tests.log (binding mismatch while paused rejected)
  HITL-07      PASS   raw-tests.log (resume after completion rejected)
  HITL-08      PASS   raw-tests.log (null action blocked)
  HITL-09      PASS   raw-tests.log (read-only auto-approved)
  HITL-10      PASS   raw-tests.log (idempotency same key different thread)
  HITL-11      PASS   raw-tests.log (verifier fail -> STOP)
  HITL-12      PASS   raw-tests.log (wrong-thread resume rejected)
  HITL-13      PASS   raw-tests.log (pending interrupt not COMPLETED)
  HITL-14      PASS   raw-tests.log (malformed/missing binding rejected)
  IDEM-01      PASS   raw-tests.log (same key different thread)
  IDEM-02      NOT VERIFIED  (idempotency across actual restart not tested)
  EXEC-01      PASS   raw-tests.log (skill execute node reached)
  VER-01       PASS   raw-tests.log (verifier PASS on SUCCESS, post_deploy FAIL -> DEBUG)
  VER-02       PASS   raw-tests.log (verifier FAIL on ERROR)
  VER-03       PASS   raw-tests.log (verifier FAIL on UNKNOWN)
  VER-04       PASS   raw-tests.log (verifier FAIL on missing skill_result)
  REC-01       PASS   raw-tests.log (router STOP on BLOCKED)
  REC-02       PASS   raw-tests.log (router STOP on REJECTED)
  REPLAN-01    PASS   raw-tests.log (REPLAN does not bypass Human Approval)
  REPLAN-02    PASS   raw-tests.log (REPLAN max attempts -> STOP)
  REPLAN-03    PASS   raw-tests.log (needs_review -> WAITING_FOR_APPROVAL)
  ROUTE-01     PASS   raw-tests.log (router default STOP)
  STATE-01     PASS   raw-tests.log (state channels serialized)
  STATE-02     PASS   raw-tests.log (skill_result in state)
  STATE-03     PASS   raw-tests.log (no secrets in state/checkpoint)
  STATE-04     PASS   raw-tests.log (pending interrupt blocks COMPLETED)
  DUR-01       NOT VERIFIED  (crash/restart recovery not tested; no persistent checkpoint)
  DUR-02       NOT VERIFIED  (concurrent resume not tested; no harness)
  DUR-03       NOT VERIFIED  (idempotency across restart not tested)

ACCEPTANCE RESULTS:
  PASS=32 FAIL=0 NOT VERIFIED=4 BLOCKED=0

DURABILITY RESULTS:
  DUR-01: NOT VERIFIED
  DUR-02: NOT VERIFIED
  DUR-03: NOT VERIFIED
  DURABILITY ACCEPTANCE: NOT VERIFIED (no persistent checkpoint / no crash/restart)

SECURITY GAPS:
  - checksums.txt still reflects 0.1.1 hashes (stale manifest)
  - No persistent checkpoint (MemorySaver only)
  - No locking for concurrent resume
  - No database-backed checkpointer available in this sandbox

SECRETS AUDIT:
  STATE-03 scanned state/checkpoint values for api_key/secret/password/token/credential – none found.

OFFICIAL NODE --TEST: NOT VERIFIED (`node --test` injects `--heap-prof-interval=524288` and fails in this environment)

P0 STATUS: PASS (all Contract v3 IN-MEMORY tests executed; DUR marked NOT VERIFIED due to missing durable backend)
READY FOR P1: YES (pending durable backend availability)

FINAL ZIP SHA256: <to be computed after final zip>

READY FOR INDEPENDENT GP REVIEW: NO
READY FOR HARESS INTEGRATION: NO
