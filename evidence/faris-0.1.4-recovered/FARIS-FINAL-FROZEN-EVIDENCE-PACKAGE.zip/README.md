# FARIS V2 Prototype - Candidate 0.1.1

## Status
- **DESIGN REVIEW**: PASS
- **CODE CANDIDATE**: FROZEN
- **EXECUTABLE PROTOTYPE**: NOT VERIFIED
- **SECURITY ACCEPTANCE CONTRACT**: NOT VERIFIED
- **READY FOR HARESS INTEGRATION**: NO

## Patch 0.1.1 (from 0.1.0)
- Renamed Node `post_deploy_verify` → `post_deploy_verify_node`
- Updated 2 edge references
- State channel `post_deploy_verify` unchanged
- No security logic changes
- No test changes
- No dependency changes

## How to Run
```bash
npm install
npm test
```
